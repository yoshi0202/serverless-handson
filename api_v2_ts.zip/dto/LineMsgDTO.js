"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class LineMsgDTO {
    constructor(type, text) {
        this.type = type;
        this.text = text;
    }
}
exports.default = LineMsgDTO;
;
//# sourceMappingURL=LineMsgDTO.js.map