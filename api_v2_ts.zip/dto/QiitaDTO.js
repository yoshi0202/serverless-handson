"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class QiitaDTO {
    constructor(title, url) {
        this.title = title;
        this.url = url;
    }
}
exports.default = QiitaDTO;
;
//# sourceMappingURL=QiitaDTO.js.map