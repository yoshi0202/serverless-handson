"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const HTTPRequest_1 = __importDefault(require("../modules/HTTPRequest"));
class WikipediaService {
    constructor() {
        this.NOT_FOUND = "検索しましたが見つかりませんでした・・・";
    }
    /**
     *
     * @param {string} title APIの検索パラメータ wikipediaのページタイトル
     */
    async searchByTitle(title) {
        const url = encodeURI("https://ja.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&titles=" + title);
        const httpRequest = new HTTPRequest_1.default();
        const result = await httpRequest.get(url);
        return this.parseResponse(result);
    }
    hoge() {
        return true;
    }
    parseResponse(object) {
        let result;
        for (const pageId in object.data.query.pages) {
            result = object.data.query.pages[pageId].extract;
        }
        if (result === undefined) {
            return this.NOT_FOUND;
        }
        if (result === "") {
            return this.NOT_FOUND;
        }
        return result;
    }
}
exports.default = WikipediaService;
;
//# sourceMappingURL=WikipediaService.js.map