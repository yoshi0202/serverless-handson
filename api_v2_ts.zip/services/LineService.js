"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const HTTPRequest_1 = __importDefault(require("../modules/HTTPRequest"));
const LineMsgDTO_1 = __importDefault(require("../dto/LineMsgDTO"));
class LineService {
    constructor() {
        this.token = "";
    }
    /**
     *
     * @param {String} LINEのチャネルトークン
     */
    setToken(token) {
        this.token = token;
    }
    /**
     *
     * @param {String} 宛先(ユーザID)
     * @param {Array} LineMsgDTOの配列
     */
    async postMessage(to, msg) {
        const httpRequest = new HTTPRequest_1.default();
        await httpRequest.post("https://api.line.me/v2/bot/message/push", {
            to: to,
            messages: msg,
        }, {
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${this.token}`,
            },
        });
    }
    /**
     *
     * @param {Array} 送信するメッセージの配列
     */
    createMessageDTOList(textArr = []) {
        const dtoArr = [];
        for (let text of textArr) {
            const lineMsgDTO = new LineMsgDTO_1.default("text", text);
            dtoArr.push(lineMsgDTO);
        }
        return dtoArr;
    }
}
exports.default = LineService;
;
//# sourceMappingURL=LineService.js.map