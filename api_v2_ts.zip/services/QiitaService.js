"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const QiitaDTO_1 = __importDefault(require("../dto/QiitaDTO"));
const HTTPRequest_1 = __importDefault(require("../modules/HTTPRequest"));
class QiitaService {
    getTitle(data) {
        return data.title;
    }
    getUrl(data) {
        return data.url;
    }
    createQiitaDTO(apiRes) {
        return new QiitaDTO_1.default(this.getTitle(apiRes), this.getUrl(apiRes));
    }
    createQiitaDTOList(apiResArray) {
        return apiResArray.map((apiRes) => {
            return this.createQiitaDTO(apiRes);
        });
    }
    async getNewArticles() {
        const httpRequest = new HTTPRequest_1.default();
        return await httpRequest.get("https://qiita.com/api/v2/items?page=1&per_page=5");
    }
    createMsgArrayByQiitaDTO(dtoList) {
        return dtoList.map(function (dto) {
            return `タイトル：${dto.title}\nURL: ${dto.url}`;
        });
    }
}
exports.default = QiitaService;
;
//# sourceMappingURL=QiitaService.js.map