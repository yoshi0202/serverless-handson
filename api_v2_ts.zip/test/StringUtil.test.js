"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const StringUtil_1 = __importDefault(require("../utils/StringUtil"));
describe('StringUtil', () => {
    test('parseSearchWord xxxx¥nとは からxxxxだけが抽出できること', () => {
        const stringUtil = new StringUtil_1.default();
        const sut = "あいうえお\nとは";
        expect(stringUtil.parseSearchWord(sut)).toBe("あいうえお");
    });
    test('validFormat xxxx¥nとは の形式になっていることをチェック', () => {
        const stringUtil = new StringUtil_1.default();
        const sut1 = "あいうえお\nとは";
        expect(stringUtil.validFormat(sut1)).toBeTruthy();
        const sut2 = "あいうえお";
        expect(stringUtil.validFormat(sut2)).toBeFalsy();
        const sut3 = "あいうえお\n\nとは";
        expect(stringUtil.validFormat(sut3)).toBeTruthy();
        const sut4 = "あいうえお \nとは";
        expect(stringUtil.validFormat(sut4)).toBeTruthy();
        const sut5 = "あいうえお\n とは";
        expect(stringUtil.validFormat(sut5)).toBeFalsy();
        const sut6 = "あいうえお\nと は";
        expect(stringUtil.validFormat(sut6)).toBeFalsy();
        const sut7 = "あいうえお\nとは ";
        expect(stringUtil.validFormat(sut7)).toBeTruthy();
        const sut8 = "あいうえお\nとは\nとは";
        expect(stringUtil.validFormat(sut8)).toBeTruthy();
    });
});
//# sourceMappingURL=StringUtil.test.js.map