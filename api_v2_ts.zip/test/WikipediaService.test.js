"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const WikipediaService_1 = __importDefault(require("../services/WikipediaService"));
describe('wikipediaService', () => {
    test('searchByTitle タイトル検索ができること', async () => {
        const wikipediaService = new WikipediaService_1.default();
        const sut1 = await wikipediaService.searchByTitle("あいうえお");
        // extractのあるページなのでキーが存在し中身が空ではない
        expect(typeof (sut1)).toBe("string");
        const sut2 = await wikipediaService.searchByTitle("l;jfkdsajouirewa");
        // // extractの存在しないページは空文字が返却
        expect(typeof (sut2)).toBe("string");
        expect(sut2).toBe(wikipediaService.NOT_FOUND);
        const sut3 = await wikipediaService.searchByTitle(" ");
        // extractの存在しないページは空文字が返却
        expect(typeof (sut3)).toBe("string");
        expect(sut3).toBe(wikipediaService.NOT_FOUND);
        const sut4 = await wikipediaService.searchByTitle("　");
        // extractの存在しないページは空文字が返却
        expect(typeof (sut4)).toBe("string");
        expect(sut4).toBe(wikipediaService.NOT_FOUND);
        const sut5 = await wikipediaService.searchByTitle("deltarune");
        // extractの存在しないページは空文字が返却
        expect(typeof (sut5)).toBe("string");
        expect(sut5).toBe(wikipediaService.NOT_FOUND);
    });
});
//# sourceMappingURL=WikipediaService.test.js.map