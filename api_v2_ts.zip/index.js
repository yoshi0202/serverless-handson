"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const IndexController_1 = __importDefault(require("./controller/IndexController"));
const HelloController_1 = __importDefault(require("./controller/HelloController"));
exports.handler = async (event) => {
    if (!process.env.LINE_TOKEN) {
        console.error(`LINE_TOKENが設定されていません LINE_TOKEN=${process.env.LINE_TOKEN}`);
        return "";
    }
    switch (event.rawPath) {
        case "/":
            return await IndexController_1.default.main(event.body);
        case "/hello":
            return await HelloController_1.default.main(event.body);
        default:
            return "";
    }
};
//# sourceMappingURL=index.js.map