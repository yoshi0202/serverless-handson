"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class StringUtil {
    constructor() {
    }
    parseSearchWord(sentence) {
        const regex = /\nとは.*$/;
        return sentence.replace(regex, "");
    }
    validFormat(sentence) {
        const regex = /\nとは.*$/;
        return sentence.match(regex) !== null;
    }
}
exports.default = StringUtil;
//# sourceMappingURL=StringUtil.js.map