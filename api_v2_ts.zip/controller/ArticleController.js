"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const QiitaService_1 = __importDefault(require("../services/QiitaService"));
const LineService_1 = __importDefault(require("../services/LineService"));
class ArticleController {
    static async main(requestBody) {
        const lineService = new LineService_1.default();
        const qiitaService = new QiitaService_1.default();
        try {
            const reqBody = JSON.parse(requestBody);
            const qiitaRes = await qiitaService.getNewArticles();
            const articleList = qiitaService.createQiitaDTOList(qiitaRes.data);
            const messageArr = qiitaService.createMsgArrayByQiitaDTO(articleList);
            lineService.setToken(process.env.LINE_TOKEN);
            const sendMessageList = lineService.createMessageDTOList(messageArr);
            await lineService.postMessage(reqBody.events[0].source.userId, sendMessageList);
            return "OK";
        }
        catch (error) {
            console.error(`Err: ${error}`);
            return `Err: ${error}`;
        }
    }
}
exports.default = ArticleController;
;
//# sourceMappingURL=ArticleController.js.map