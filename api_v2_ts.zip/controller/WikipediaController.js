"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const LineService_1 = __importDefault(require("../services/LineService"));
const WikipediaService_1 = __importDefault(require("../services/WikipediaService"));
const StringUtil_1 = __importDefault(require("../utils/StringUtil"));
class WikipediaController {
    static async main(requestBody) {
        const lineService = new LineService_1.default();
        const wikipediaService = new WikipediaService_1.default();
        const stringUtil = new StringUtil_1.default();
        try {
            const reqBody = JSON.parse(requestBody);
            const message = reqBody.events[0].message.text;
            let wikiSearched;
            console.log(reqBody.events[0].message.text);
            if (stringUtil.validFormat(message)) {
                const parsedText = stringUtil.parseSearchWord(reqBody.events[0].message.text);
                wikiSearched = await wikipediaService.searchByTitle(parsedText);
            }
            else {
                wikiSearched = "~~~\nとはの形式で入力してください！";
            }
            lineService.setToken(process.env.LINE_TOKEN);
            const sendMessageList = lineService.createMessageDTOList([wikiSearched]);
            await lineService.postMessage(reqBody.events[0].source.userId, sendMessageList);
            return "OK";
        }
        catch (error) {
            console.error(`Err: ${error}`);
            return `Err: ${error}`;
        }
    }
}
exports.default = WikipediaController;
;
//# sourceMappingURL=WikipediaController.js.map