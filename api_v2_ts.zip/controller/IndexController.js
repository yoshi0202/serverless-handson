"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const ArticleController_1 = __importDefault(require("./ArticleController"));
const DefaultController_1 = __importDefault(require("./DefaultController"));
class IndexController {
    static async main(requestBody) {
        try {
            const receiveMsg = JSON.parse(requestBody).events[0].message.text;
            switch (true) {
                case /^.*(Qiita|qiita|キータ)/.test(receiveMsg):
                    return await ArticleController_1.default.main(requestBody);
                default:
                    return await DefaultController_1.default.main(requestBody);
            }
        }
        catch (error) {
            return {
                statusCode: "200",
                body: error,
            };
        }
    }
}
exports.default = IndexController;
;
//# sourceMappingURL=IndexController.js.map