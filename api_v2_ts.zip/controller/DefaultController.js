"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const LineService_1 = __importDefault(require("../services/LineService"));
class DefaultController {
    static async main(requestBody) {
        const lineService = new LineService_1.default();
        try {
            const body = JSON.parse(requestBody);
            lineService.setToken(process.env.LINE_TOKEN);
            const sendMessageList = lineService.createMessageDTOList([
                "メッセージ内に[Qiita], [qiita], [キータ]を含んで送信してください",
            ]);
            await lineService.postMessage(body.events[0].source.userId, sendMessageList);
            return "OK";
        }
        catch (error) {
            console.error(`Err: ${error}`);
            return `Err: ${error}`;
        }
    }
}
exports.default = DefaultController;
;
//# sourceMappingURL=DefaultController.js.map