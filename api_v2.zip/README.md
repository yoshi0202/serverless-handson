# serverless-handson

12/19 開催の「サーバレスアーキテクチャで LINE BOT が多分作れるようになるハンズオン」で利用するソースコード群

資料：[url](WIP)
