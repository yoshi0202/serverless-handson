module.exports = class LineMsgDTO {
  constructor(type, text) {
    this.type = type;
    this.text = text;
  }
};
