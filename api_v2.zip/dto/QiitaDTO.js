module.exports = class QiitaDTO {
  constructor(title, url) {
    this.title = title;
    this.url = url;
  }
};
